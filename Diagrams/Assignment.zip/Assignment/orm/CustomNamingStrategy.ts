import { DefaultNamingStrategy, NamingStrategyInterface } from "typeorm";
/**
 * Providing custom naming strategy as per user specificied name.
 */
export class CustomNamingStrategy
  extends DefaultNamingStrategy
  implements NamingStrategyInterface
{
  tableName(targetName: string, userSpecifiedName: string | undefined): string {
    return userSpecifiedName || targetName;
  }
}

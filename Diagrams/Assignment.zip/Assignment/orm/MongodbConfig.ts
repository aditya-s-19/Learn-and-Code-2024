import { DbType } from "../../common/enums";
import { ConfigManager } from "../../config/ConfigManager";
import { join } from "path";

const config = ConfigManager.getConfig();

/**
 * class for configuring a MongoDB database connection.
 */
export default class MongodbConfig {
  /**
   * The url of the database server.
   */
  private url: string;
  /**
   * The name of the database to connect.
   */
  private database: string;
  /**
   * Indicates whether database synchronization should be enabled.
   */
  private synchronize: boolean;
  /**
   * Indicates whether database logging should be enabled.
   */
  private logging: boolean;
  /**
   * The type of the database.
   */
  private type: DbType;
  /**
   * An array of entity file patterns used for database.
   */
  private entities: string[];

  /**
   * Constructor for the MongodbConfig class.
   */
  constructor() {
    const mongoConfig = { ...config.mongodb };
    this.url = process.env.MONGO_DB_URL || "";
    this.database = process.env.MONGO_DB_NAME || "";
    this.synchronize = mongoConfig.synchronize;
    this.logging = mongoConfig.logging;
    this.type = DbType.MONGODB;
    this.entities = [
      join(__dirname, "/entities/mongodb/*.{ts,js}"),
      // join(__dirname, "/views/*.{ts,js}"),
    ];
  }

  /**
   * Retrieves the MongoDB database configuration.
   * @returns The MongoDB database configuration object.
   */
  public get dbConfig() {
    return {
      type: this.type,
      useUnifiedTopology: true,
      url: this.url,
      database: this.database,
      synchronize: this.synchronize,
      logging: this.logging,
      entities: this.entities,
      retryWrites: false,
      migrations: [join(__dirname, "/../../migrations/mongo/*.{ts,js}")],
    };
  }
}

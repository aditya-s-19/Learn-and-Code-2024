import { ObjectLiteral } from "typeorm";
import DatabaseConnection from "./DatabaseConnection";
import DatabaseFactory from "./DatabaseFactory";
import { DbType } from "../../common/enums";

/**
 * A base class for handling database connections.
 */
export class Base {
  /**
   * The database connection instance.
   */
  private connection!: DatabaseConnection;

  /**
   * Gets the database connection based on the provided database type.
   * @template T The type of the database connection.
   * @param dbType The type of the database.
   * @returns A promise that resolves to the database connection.
   */
  protected async getConnection<T extends ObjectLiteral>(dbType: DbType) {
    if (!this.connection) {
      this.connection = await DatabaseFactory.getConnection(dbType);
    }
    return this.connection.Pool.manager;
  }
}

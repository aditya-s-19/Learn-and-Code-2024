import { DataSourceOptions } from "typeorm";
import DatabaseConnection from "./DatabaseConnection";
import MongodbConfig from "./MongodbConfig";

/**
 * class for managing a connection to a MongoDB database.
 */
export default class MongodbConnection extends DatabaseConnection {
  private static instance: MongodbConnection;

  /**
   * Constructor for the MongodbConnection class.
   * @param config Configuration for the database connection.
   */
  private constructor(readonly config: DataSourceOptions) {
    super(config);
  }

  /**
   * Creating new Connection instance for MongoDB.
   */
  public static get Instance() {
    if (!this.instance) {
      this.instance = new MongodbConnection(new MongodbConfig().dbConfig);
    }
    return this.instance;
  }
}

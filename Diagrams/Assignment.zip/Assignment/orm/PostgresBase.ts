import { EntityTarget, ObjectLiteral } from "typeorm";
import { Base } from "./Base";
import { DbType } from "../../common/enums";

/**
 * A base class for PostgreSQL-related database operations.
 */
export class PostgresBase extends Base {
  /**
   * Constructs a new instance of the PostgresBase class.
   */
  protected constructor() {
    super();
  }

  /**
   * Gets a repository instance for the provided entity.
   * @template T The type of the repository entity.
   * @param entity The entity for which to get the repository.
   * @returns A repository instance for the provided entity.
   */
  protected async getRepository<T extends ObjectLiteral>(
    entity: EntityTarget<T>
  ) {
    const manager = await super.getConnection(DbType.POSTGRES);
    return manager.getRepository(entity);
  }
}

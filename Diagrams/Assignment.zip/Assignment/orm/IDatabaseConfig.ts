import { DbType } from "../../common/enums";

/**
 * Interface that defines the configuration for a database connection.
 */
export default interface IDatabaseConfig {
  /**
   * The type of the database.
   */
  type?: DbType;
  /**
   * The host where the database server is located.
   */
  host: string;
  /**
   * The port number to connect to the database server.
   */
  port: number;
  /**
   * The name of the database to connect to.
   */
  database: string;
  /**
   * The username used for authentication with the database server.
   */
  username: string;
  /**
   * The password used for authentication with the database server.
   */
  password: string;
  /**
   * Indicates whether database schema should be automatically synchronized.
   */
  synchronize: boolean;
  /**
   * Indicates whether database query logging should be enabled.
   */
  logging: boolean;
  /**
   * An optional array of entity class names or paths to entities.
   */
  entities?: string[];
}

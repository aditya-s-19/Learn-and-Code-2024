import PostgresConnection from "./PostgreConnection";
import MongodbConnection from "./MongodbConnection";
import { DbType } from "../../common/enums";

/**
 * Class responsible for creating and providing database connection instances.
 */
export default class DatabaseFactory {
  /**
   * Returns an instance of the appropriate database configuration.
   * @param type The type of the database.
   */
  static getInstance(type: DbType) {
    switch (type) {
      case DbType.POSTGRES:
        return PostgresConnection.Instance;
      case DbType.MONGODB:
        return MongodbConnection.Instance;
      default:
        throw new Error(`DbType: ${type} not implemented`);
    }
  }

  /**
   * Returns an instance of the appropriate database connection.
   * @param type The type of the database.
   */
  static async getConnection(type: DbType) {
    const db = this.getInstance(type);
    await db.initialize();
    return db;
  }
}

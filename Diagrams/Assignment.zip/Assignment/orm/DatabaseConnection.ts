require("reflect-metadata");
import { DataSource, DataSourceOptions } from "typeorm";
import logger from "../../../app/logger";

/**
 * An abstract class representing a database connection, and provides methods to manage the connection.
 */
export default abstract class DatabaseConnection {
  protected pool!: DataSource;

  /**
   * Constructs a DatabaseConnection instance.
   * @param config The configuration for the database connection.
   */
  constructor(protected readonly config: DataSourceOptions) {
    try {
      if (!this.pool) {
        this.pool = new DataSource(this.config);
      }
    } catch (error) {
      logger.error(error as Error);
    }
  }

  /**
   * Initialize the new database connction.
   */
  public async initialize() {
    if (!this.pool.isInitialized) {
      await this.pool.initialize();
    }
  }

  /**
   * Disconnects from the database pool.
   * @returns A promise that resolves when the disconnection is complete.
   */
  async disconnect(): Promise<void> {
    await this.pool.destroy();
  }

  /**
   * Gets the database pool instance.
   * @returns The database pool instance.
   */
  public get Pool(): DataSource {
    return this.pool;
  }
}

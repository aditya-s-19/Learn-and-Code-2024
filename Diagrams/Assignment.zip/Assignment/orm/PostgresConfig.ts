import { join } from "path";
import { CustomNamingStrategy } from "./CustomNamingStrategy";
import { ConfigManager } from "../../config/ConfigManager";
import { DbType } from "../../common/enums";

const config = ConfigManager.getConfig();
/**
 * class for configuring Postgres database settings.
 */
export default class PostgresConfig {
  host: string;
  port: number;
  /**
   * The name of the database to connect.
   */
  database: string;
  username: string;
  password: string;
  /**
   * Indicates whether database synchronization should be enabled.
   */
  synchronize: boolean;
  /**
   * Indicates whether database logging should be enabled.
   */
  logging: boolean;
  poolSize: number;
  /**
   * The type of the database.
   */
  private type: DbType;
  /**
   * An array of entity file patterns used for database.
   */
  private entities: string[];

  constructor() {
    const postgresConfig = { ...config.postgres };
    this.host = process.env.PGHOST || "";
    this.port = Number(process.env.PGPORT);
    this.database = process.env.PGDATABASE || "";
    this.username = process.env.PGUSER || "";
    this.synchronize = postgresConfig.synchronize;
    this.password = process.env.PGPASSWORD || "";
    this.logging = postgresConfig.logging;
    this.poolSize = postgresConfig.poolSize;
    this.type = DbType.POSTGRES;
    this.entities = [join(__dirname, "/entities/pgSql/*.{ts,js}")];
  }

  /**
   * Get the database configuration object.
   * @returns The database configuration object.
   */
  public get dbConfig() {
    return {
      type: this.type,
      host: this.host,
      port: this.port,
      database: this.database,
      username: this.username,
      synchronize: this.synchronize,
      password: this.password,
      logging: this.logging,
      poolSize: this.poolSize,
      entities: this.entities,
      migrations: [join(__dirname, "/../../migrations/pg/*.{ts,js}")],
      namingStrategy: new CustomNamingStrategy(),
    };
  }
}

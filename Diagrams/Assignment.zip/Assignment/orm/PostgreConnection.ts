import { DataSourceOptions } from "typeorm";
import DatabaseConnection from "./DatabaseConnection";
import PostgresConfig from "./PostgresConfig";

/**
 * class for managing a connection to a PostgreSQL database.
 */
export default class PostgresConnection extends DatabaseConnection {
  private static instance: PostgresConnection;

  /**
   * Constructor for the PostgresConnection class.
   * @param config Configuration for the database connection.
   */
  private constructor(readonly config: DataSourceOptions) {
    super(config);
  }

  /**
   * Creating new Connection instance for Postgres.
   */
  public static get Instance() {
    if (!this.instance) {
      this.instance = new PostgresConnection(new PostgresConfig().dbConfig);
    }
    return this.instance;
  }
}

import logger, { LogAllMethods } from "../../../../../app/logger";
import { Follows } from "../../../orm/entities/pgSql/Follows";
import { PostgresBase as Base } from "../../../orm/PostgresBase";
import { IFollowRepository } from "../../types/follow";
import User from "../../../../models/user";
import { ErrorResponse } from "../../../../responseManager/errorResponse";
import { Errors } from "../../../../responseManager/errors";

@LogAllMethods
export class FollowRepository extends Base implements IFollowRepository {
  private static instance: FollowRepository;

  private constructor() {
    super();
  }

  public async addFollower(
    followerId: number,
    followeeId: number
  ): Promise<number> {
    try {
      const followRepository = await super.getRepository(Follows);
      const newFollower = followRepository.create({
        followerId: followerId,
        followeeId: followeeId,
      });
      const follower = await followRepository.save(newFollower);
      logger.info(`${followeeId} started following ${followerId}`);
      return followeeId;
    } catch (ex: any) {
      if (ex.code === "23505") {
        logger.error("DBLayer: addFollower Error -", ex);
        throw new ErrorResponse(
          Errors.BadRequestError,
          "ERROR_DUPLICATE_FOLLOW",
          [ex]
        );
      } else {
        logger.error("DBLayer: addFollower Error -", ex);
        throw new ErrorResponse(Errors.DatabaseError, "ERROR_FOLLOW", [ex]);
      }
    }
  }

  public async deleteFollower(
    followerId: number,
    followeeId: number
  ): Promise<number | null> {
    const followRepository = await super.getRepository(Follows);
    const deleteFollower = followRepository.delete({
      followeeId: followeeId,
      followerId: followerId,
    });
    logger.info(`User - ${followeeId} unfollowed ${followerId}`);
    return (await deleteFollower).affected!;
  }

  public async getFollowersByFolloweeId(
    followeeId: number
  ): Promise<Partial<User>[]> {
    try {
      const followRepository = await super.getRepository(Follows);
      const follows = await followRepository.find({
        where: { followee: { id: followeeId } },
        relations: ["follower"], // Eagerly load the follower relation
      });
      logger.info("Get All Followers of User");
      return follows.map((follow) => ({
        id: follow.follower.id,
        email: follow.follower.email,
        fullname: follow.follower.fullname,
        dob: follow.follower.dob,
        username: follow.follower.username,
        profileImg: follow.follower.profileImg,
      }));
    } catch (ex: any) {
      logger.error("DBLayer: getFollowees Error -", ex);
      throw new ErrorResponse(Errors.DatabaseError, ex.message, [ex]);
    }
  }

  public async getFolloweesByFollowerId(
    followerId: number
  ): Promise<Partial<User>[]> {
    try {
      const followRepository = await super.getRepository(Follows);
      // Use the find method to get the followed users
      const follows = await followRepository.find({
        where: { follower: { id: followerId } },
        relations: ["followee"], // Eagerly load the followee relation
      });
      logger.info("Get All Followees of User");
      return follows.map((follow) => ({
        id: follow.followee.id,
        email: follow.followee.email,
        fullname: follow.followee.fullname,
        dob: follow.followee.dob,
        username: follow.followee.username,
        profileImg: follow.followee.profileImg,
      }));
    } catch (ex: any) {
      logger.error("DBLayer: getFollowers Error -", ex);
      throw new ErrorResponse(Errors.DatabaseError, ex.message, [ex]);
    }
  }

  /**
   * @returns The instance of the FollowRepository.
   */
  public static get Instance(): FollowRepository {
    if (!this.instance) {
      this.instance = new FollowRepository();
      logger.info("Connected to ORM - FollowRepository");
    }
    return this.instance;
  }
}

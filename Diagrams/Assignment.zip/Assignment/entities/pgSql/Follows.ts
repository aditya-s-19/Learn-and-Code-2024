import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Users } from "./Users";

@Index("unique_follower_followee", ["followeeId", "followerId"], {
  unique: true,
})
@Index("follows_pkey", ["id"], { unique: true })
@Entity("follows", { schema: "public" })
export class Follows {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id?: number;

  @Column("timestamp without time zone", {
    name: "created_at",
    nullable: true,
    default: () => "CURRENT_TIMESTAMP",
  })
  createdAt?: Date | null;

  @Column("timestamp without time zone", {
    name: "updated_at",
    nullable: true,
    default: () => "CURRENT_TIMESTAMP",
  })
  updatedAt?: Date | null;

  @Column("integer", { name: "follower_id" })
  followerId!: number;

  @Column("integer", { name: "followee_id" })
  followeeId!: number;

  @ManyToOne(() => Users, (users) => users.followers)
  @JoinColumn([{ name: "followee_id", referencedColumnName: "id" }])
  followee!: Users;

  @ManyToOne(() => Users, (users) => users.followees)
  @JoinColumn([{ name: "follower_id", referencedColumnName: "id" }])
  follower!: Users;
}

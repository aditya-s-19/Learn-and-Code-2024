import User from "../../../models/user";

export interface IFollowRepository {
  /**
   * Adds a follower to a followee.
   *
   * @param {number} followerId - The ID of the user who is following.
   * @param {number} followeeId - The ID of the user to be followed.
   * @returns {Promise<number>} - A promise that resolves to the ID of the newly created follow relationship.
   */
  addFollower(followerId: number, followeeId: number): Promise<number>;

  /**
   * Removes a follower from a followee.
   *
   * @param {number} followerId - The ID of the user who is unfollowing.
   * @param {number} followeeId - The ID of the user to be unfollowed.
   * @returns {Promise<number | null>} - A promise that resolves to the ID of the deleted follow relationship, or `null` if no relationship was found.
   */
  deleteFollower(
    followerId: number,
    followeeId: number
  ): Promise<number | null>;
  /**
   * Retrieves a list of followers for a specific followee.
   *
   * @param {number} followeeId - The ID of the user whose followers are being retrieved.
   * @returns {Promise<Partial<User>[]>} - A promise that resolves to an array of user objects representing the followers.
   */
  getFollowersByFolloweeId(followeeId: number): Promise<Partial<User>[]>;

  /**
   * Retrieves a list of users that a specific follower is following.
   *
   * @param {number} followerId - The ID of the user whose followees are being retrieved.
   * @returns {Promise<Partial<User>[]>} - A promise that resolves to an array of user objects representing the followees.
   */
  getFolloweesByFollowerId(followerId: number): Promise<Partial<User>[]>;
}

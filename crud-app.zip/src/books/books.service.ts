import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { CreateBookDto } from './dtos/create-book.dto';
import { UpdateBookDto } from './dtos/update-book.dto';
import { BooksValidator } from './books.validator';
import { BooksRepository } from './books.repository';

@Injectable()
export class BooksService {
  constructor(
    private booksValidator: BooksValidator,
    private booksRepository: BooksRepository,
  ) {}

  getBooks() {
    return this.booksRepository.getAllBooks();
  }

  getBookById(id: string) {
    this.booksValidator.existsById(id);
    return this.booksRepository.getBookById(id);
  }

  createBook(newBook: CreateBookDto) {
    this.booksValidator.validateNewBook(newBook);
    return this.booksRepository.createNewBook(newBook);
  }

  updateBook(updatedBook: UpdateBookDto) {
    this.booksValidator.validateUpdatedBook(updatedBook);
    return this.booksRepository.updateOldBook(updatedBook);
  }

  deleteBookById(id: string) {
    this.booksValidator.existsById(id);
    this.booksRepository.deleteBookById(id);
  }
}

import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateBookDto } from './dtos/create-book.dto';
import { UpdateBookDto } from './dtos/update-book.dto';
import { BooksRepository } from './books.repository';

@Injectable()
export class BooksValidator {
  constructor(private booksRepository: BooksRepository) {}

  existsById(id: string) {
    if (!this.booksRepository.getBookById(id))
      throw new NotFoundException(`Book with id: ${id} does not exist`);
  }

  doesNotExistByName(name: string) {
    if (this.booksRepository.searchBooksByName(name).length)
      throw new BadRequestException(`Book with name: ${name} already exists`);
  }

  validateNewBook(newBook: CreateBookDto) {
    this.doesNotExistByName(newBook.name);
  }

  validateUpdatedBook(updatedBook: UpdateBookDto) {
    this.existsById(updatedBook.id);
    const booksWithSameName = this.booksRepository.searchBooksByName(
      updatedBook.name,
    );
    const isDuplicateName =
      (booksWithSameName.length === 1 &&
        booksWithSameName[0].id !== updatedBook.id) ||
      booksWithSameName.length > 1;

    if (isDuplicateName) {
      throw new BadRequestException(
        `Book with name: ${updatedBook.name} already exists`,
      );
    }
  }
}

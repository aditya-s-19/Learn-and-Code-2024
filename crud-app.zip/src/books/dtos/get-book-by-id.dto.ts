import { IsUUID } from 'class-validator';

export class GetBookByIdDto {
  @IsUUID('4', { message: 'Invalid UUID v4 format' })
  id: string;
}

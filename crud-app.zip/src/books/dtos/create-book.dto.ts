import { Transform } from 'class-transformer';
import {
  IsDate,
  IsDateString,
  IsEnum,
  IsString,
  MaxLength,
  Validate,
} from 'class-validator';
import { BookGenre } from '../../constants/genres.enum';
import { IsPastDateConstraint } from '../../utils/validators/is-past-date-validator';

export class CreateBookDto {
  @IsString()
  @MaxLength(100)
  name: string;

  @IsString()
  @MaxLength(100)
  author: string;

  @IsEnum(BookGenre, {
    message: `Genre must be one of: ${Object.values(BookGenre).join(', ')}`,
  })
  genre: BookGenre;

  @Transform(({ value }) => new Date(value))
  @IsDate()
  @Validate(IsPastDateConstraint)
  publishDate: Date;
}

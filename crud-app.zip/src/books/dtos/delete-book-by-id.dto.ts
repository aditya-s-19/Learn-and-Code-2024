import { GetBookByIdDto } from './get-book-by-id.dto';

export class DeleteBookByIdDto extends GetBookByIdDto {}

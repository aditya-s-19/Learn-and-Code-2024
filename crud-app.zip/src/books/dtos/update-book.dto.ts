import { IsUUID } from 'class-validator';
import { CreateBookDto } from './create-book.dto';

export class UpdateBookDto extends CreateBookDto {
  @IsUUID('4', { message: 'ID must be a valid UUID v4' })
  id: string;
}

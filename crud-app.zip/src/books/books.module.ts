import { Module } from '@nestjs/common';
import { BooksController } from './books.controller';
import { BooksService } from './books.service';
import { BooksRepository } from './books.repository';
import { BooksValidator } from './books.validator';

@Module({
  controllers: [BooksController],
  providers: [BooksService, BooksRepository, BooksValidator],
})
export class BooksModule {}

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
} from '@nestjs/common';
import { CreateBookDto } from './dtos/create-book.dto';
import { IsUUID } from 'class-validator';
import { GetBookByIdDto } from './dtos/get-book-by-id.dto';
import { UpdateBookDto } from './dtos/update-book.dto';
import { DeleteBookByIdDto } from './dtos/delete-book-by-id.dto';
import { BooksService } from './books.service';

@Controller('books')
export class BooksController {
  constructor(private booksService: BooksService) {}

  @Get()
  getBooks() {
    this.booksService.getBooks();
  }

  @Get(':id')
  getBookById(@Param() params: GetBookByIdDto) {
    this.booksService.getBookById(params.id);
  }

  @Post()
  createBook(@Body() body: CreateBookDto) {
    this.booksService.createBook(body);
  }

  @Put()
  updateBook(@Body() body: UpdateBookDto) {
    this.booksService.updateBook(body);
  }

  @Delete(':id')
  deleteBookById(@Param() params: DeleteBookByIdDto) {
    this.booksService.deleteBookById(params.id);
  }
}

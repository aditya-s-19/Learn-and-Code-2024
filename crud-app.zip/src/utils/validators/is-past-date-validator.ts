import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';

@ValidatorConstraint({ name: 'isPastDate', async: false })
export class IsPastDateConstraint implements ValidatorConstraintInterface {
  validate(value: Date) {
    return value instanceof Date && value.getTime() < Date.now();
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} must be a date in the past`;
  }
}
